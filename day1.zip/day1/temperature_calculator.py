name = input("Enter patient's name: ")

temperature = input("Enter patient's temperature: ")

print ("Name: " + name)
print ("Temperature: " + temperature)

diff_from_369 = float(temperature) - 36.9

print(name +"'s temperature is " + str(diff_from_369) + " degree from 36.9 degree celsius")
